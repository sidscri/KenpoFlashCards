/**
 * Kenpo Flashcards Sync API - Add to your Express.js server
 * File: c:/personal-servers/kenpoflashcardswebserver/routes/sync-api.js
 * Usage: const syncApi = require('./routes/sync-api'); app.use('/api', syncApi);
 */
const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
const PROFILES_FILE = path.join(DATA_DIR, 'profiles.json');
const BREAKDOWNS_FILE = path.join(DATA_DIR, 'breakdown.json');
const USERS_DIR = path.join(DATA_DIR, 'users');

[DATA_DIR, USERS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// Simple token storage (in production, use JWT or Redis)
const tokens = new Map();

function readJson(file, def = {}) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return def; } }
function writeJson(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }

// POST /api/login - { username, password } -> { token, userId, username }
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const profiles = readJson(PROFILES_FILE, { users: [] });
    const user = profiles.users.find(u => u.username === username);
    if (!user) return res.status(401).json({ error: 'User not found' });
    // Simple password check (in production, use bcrypt)
    if (user.password !== password && user.passwordHash !== crypto.createHash('sha256').update(password).digest('hex')) {
        return res.status(401).json({ error: 'Invalid password' });
    }
    const token = crypto.randomBytes(32).toString('hex');
    tokens.set(token, { id: user.id, username: user.username, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 });
    res.json({ token, userId: user.id, username: user.username });
});

// Auth middleware
function auth(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ error: 'No token' });
    const token = authHeader.slice(7);
    const session = tokens.get(token);
    if (!session || session.exp < Date.now()) return res.status(401).json({ error: 'Invalid token' });
    req.user = session;
    next();
}

// GET /api/sync/pull - Get user progress
router.get('/sync/pull', auth, (req, res) => {
    const userDir = path.join(USERS_DIR, req.user.id);
    if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
    const progress = readJson(path.join(userDir, 'progress.json'), {});
    res.json({ progress });
});

// POST /api/sync/push - Save user progress
router.post('/sync/push', auth, (req, res) => {
    const userDir = path.join(USERS_DIR, req.user.id);
    if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
    writeJson(path.join(userDir, 'progress.json'), req.body.progress || {});
    res.json({ success: true });
});

// GET /api/breakdowns - Get shared breakdowns
router.get('/breakdowns', (req, res) => {
    res.json({ breakdowns: readJson(BREAKDOWNS_FILE, {}) });
});

// POST /api/breakdowns - Save breakdown (requires auth)
router.post('/breakdowns', auth, (req, res) => {
    const breakdowns = readJson(BREAKDOWNS_FILE, {});
    const bd = req.body;
    if (bd.id) { breakdowns[bd.id] = { ...bd, updated_by: req.user.username, updated_at: Math.floor(Date.now() / 1000) }; }
    writeJson(BREAKDOWNS_FILE, breakdowns);
    res.json({ success: true });
});

// POST /api/sync/customset - Save custom set
router.post('/sync/customset', auth, (req, res) => {
    const userDir = path.join(USERS_DIR, req.user.id);
    if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
    writeJson(path.join(userDir, 'customset.json'), req.body.customSet || []);
    res.json({ success: true });
});

module.exports = router;
