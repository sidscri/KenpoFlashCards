Branding safety note (temporary)
================================

Until you have written permission to use any third‑party trademarks/logos,
keep the web app's icon and UI branding generic (e.g., "Kenpo Vocabulary Study Flashcards")
and do not include company names/logos that might be trademarked.

This patch includes a simple generic favicon (a white 'K' on a dark square).
Replace it later once you have permission.
