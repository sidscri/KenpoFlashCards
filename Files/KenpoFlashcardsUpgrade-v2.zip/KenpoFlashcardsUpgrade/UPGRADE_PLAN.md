# Kenpo Flashcards: Web → Android Upgrade Plan

## Executive Summary

This document outlines the features, data, and design differences between **KenpoFlashcardsWeb** (the advanced web app) and **KenpoFlashCardsAndroidApp** (the basic F-Droid Android app), with a plan to port the web app's features to Android.

---

## Feature Comparison

### Current Android App Features
| Feature | Status |
|---------|--------|
| Basic flashcard display | ✅ |
| Flip card animation | ✅ |
| Swipe navigation | ✅ |
| Learned/Active/Deleted tracking | ✅ |
| Text-to-speech (basic) | ✅ |
| Group/Subgroup filtering | ✅ |
| Search | ✅ |
| Random/sorted modes | ✅ |
| CSV import | ✅ |
| Dark theme | ✅ |

### Web App Features (To Port)
| Feature | Priority | Complexity |
|---------|----------|------------|
| **Unsure status** (3-state: active/unsure/learned) | HIGH | Medium |
| **Learned Study mode** (review learned cards) | HIGH | Medium |
| **Term Breakdowns** (parts + literal meaning) | HIGH | High |
| **AI Auto-fill for breakdowns** (OpenAI/Gemini) | MEDIUM | High |
| **Show breakdown on definition side** | MEDIUM | Low |
| **Voice customization** (voice selection, rate) | MEDIUM | Medium |
| **Per-tab randomization settings** | LOW | Low |
| **Linked randomization across tabs** | LOW | Low |
| **All Cards view** (list all cards) | MEDIUM | Low |
| **Better settings UI** with sections | LOW | Medium |

---

## Data Structure Changes

### Current Android Data Model
```kotlin
data class FlashCard(
    val id: String,
    val group: String,
    val subgroup: String?,
    val term: String,
    val pron: String?,
    val meaning: String,
)

// Progress: learned/deleted only
data class ProgressState(
    val learnedIds: Set<String>,
    val deletedIds: Set<String>
)
```

### Proposed Enhanced Data Model
```kotlin
data class FlashCard(
    val id: String,
    val group: String,
    val subgroup: String?,
    val term: String,
    val pron: String?,
    val meaning: String,
)

enum class CardStatus { ACTIVE, UNSURE, LEARNED, DELETED }

data class ProgressState(
    val statuses: Map<String, CardStatus>,  // id -> status
)

data class TermBreakdown(
    val id: String,
    val term: String,
    val parts: List<BreakdownPart>,
    val literal: String,
    val notes: String,
    val updatedAt: Long,
    val updatedBy: String?
)

data class BreakdownPart(
    val part: String,
    val meaning: String
)
```

### Settings Expansion
```kotlin
data class StudySettings(
    // Existing
    val selectedGroup: String? = null,
    val selectedSubgroup: String? = null,
    val sortMode: SortMode = SortMode.RANDOM,
    val randomize: Boolean = true,
    val showGroup: Boolean = true,
    val showSubgroup: Boolean = true,
    val reverseCards: Boolean = false,
    
    // New from Web
    val randomizeUnlearned: Boolean = false,
    val randomizeUnsure: Boolean = false,
    val randomizeLearnedStudy: Boolean = false,
    val linkRandomizeTabs: Boolean = true,
    val showBreakdownOnDefinition: Boolean = false,
    val showDefinitionsInList: Boolean = true,
    
    // Voice settings
    val speechVoice: String? = null,
    val speechRate: Float = 1.0f,
)
```

---

## UI/Design Porting

### Color Scheme (Web)
```css
--bg: #0f1217      /* Dark background */
--panel: #151a22   /* Card/panel background */
--panel2: #11161f  /* Input/secondary background */
--border: #2b3140  /* Border color */
--text: #eaeef7    /* Primary text */
--muted: #b7c0d4   /* Secondary text */
```

### Android Theme Adaptation (values/colors.xml)
```xml
<resources>
    <color name="bg_dark">#0F1217</color>
    <color name="panel_dark">#151A22</color>
    <color name="panel2_dark">#11161F</color>
    <color name="border_dark">#2B3140</color>
    <color name="text_dark">#EAEEF7</color>
    <color name="muted_dark">#B7C0D4</color>
    <color name="accent_good">#12311F</color>
    <color name="accent_good_border">#1D5A35</color>
    <color name="accent_danger">#321313</color>
    <color name="accent_danger_border">#6E2222</color>
</resources>
```

---

## Implementation Phases

### Phase 1: Core Enhancements (High Priority)
1. **Add "Unsure" status**
   - Modify `Store.kt` to track 4 states instead of 2
   - Add Unsure screen/tab
   - Update buttons: "Got it", "Unsure", "Relearn"

2. **Learned Study Mode**
   - Add toggle in Learned screen: List vs Study
   - Study mode allows reviewing learned cards
   - "Relearn" and "Still Unsure" buttons

3. **Term Breakdowns (Local Storage)**
   - Add `breakdowns.json` storage
   - Create Breakdown modal/screen
   - Manual entry: parts + literal meaning + notes

### Phase 2: Enhanced Features (Medium Priority)
4. **Show Breakdown on Definition**
   - Toggle in settings
   - Display breakdown info on card back

5. **Voice Customization**
   - Voice selection dropdown
   - Speech rate slider (0.5x - 2.0x)
   - Test voice button

6. **All Cards View**
   - New tab showing all cards regardless of status
   - Quick status change buttons

### Phase 3: Advanced Features (Lower Priority)
7. **AI Breakdown Auto-fill**
   - Optional OpenAI/Gemini integration
   - Store API key in app preferences
   - Auto-fill button in breakdown editor

8. **Per-Tab Randomization**
   - Separate random toggles per tab
   - Link/unlink randomization setting

---

## Files to Modify

### Android App Files
| File | Changes |
|------|---------|
| `Models.kt` | Add `CardStatus`, `TermBreakdown`, `BreakdownPart` |
| `StudySettings.kt` | Add new settings fields |
| `Store.kt` | Add breakdown storage, update progress storage |
| `Repository.kt` | Add breakdown methods, update progress methods |
| `MainActivity.kt` | Major UI changes, new screens, breakdown modal |
| `TtsHelper.kt` | Add voice selection, rate control |
| `values/colors.xml` | Add web-style dark theme colors |
| `values/themes.xml` | Update theme to match web |

### New Files to Create
| File | Purpose |
|------|---------|
| `BreakdownModels.kt` | Breakdown data classes |
| `BreakdownStore.kt` | Breakdown persistence |
| `UnsureScreen.kt` | Unsure cards screen (could be in MainActivity) |
| `AllCardsScreen.kt` | All cards list view |
| `BreakdownEditor.kt` | Breakdown editing composable |
| `VoiceSettings.kt` | Voice configuration composable |

---

## JSON Data Format

The `kenpo_words.json` format is already compatible! No changes needed to the data file.

### Breakdowns Storage Format (New)
```json
{
  "card_id_here": {
    "id": "card_id_here",
    "term": "Taekwondo",
    "parts": [
      {"part": "Tae", "meaning": "Foot"},
      {"part": "Kwon", "meaning": "Hand/Fist"},
      {"part": "Do", "meaning": "Way"}
    ],
    "literal": "The Way of the Foot and Fist",
    "notes": "Korean martial art",
    "updated_at": 1704672000,
    "updated_by": "user"
  }
}
```

---

## Migration Strategy

1. **Keep existing data compatible** - Don't break current user progress
2. **Gradual rollout** - Add features incrementally
3. **Shared breakdowns file** - Could sync with web app via export/import

---

## Next Steps

1. Review this plan
2. Choose which features to implement first
3. Use the companion web tool (created alongside this document) to regenerate updated files when needed
