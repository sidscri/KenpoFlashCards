# Kenpo Flashcards Web (Companion)

This runs a local web UI that reads your Android app's flashcard data directly from:

`C:\Users\Sidscri\Documents\GitHub\KenpoFlashCards\KenpoFlashcardsProject\app\src\main\assets\kenpo_words.json`

## Run (Windows PowerShell)

```powershell
cd C:\KenpoFlashcardsWeb
py -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open:
- http://localhost:8009
- http://192.168.0.129:8009

## Notes
- Progress is stored locally in `progress.json` (Active / Unsure / Learned / Deleted).
- Settings are stored in `progress.json` and can be set per group or for all groups.
- If LAN access fails, allow firewall TCP 8009.


## Multi-user profiles
- First visit: create a profile (first + last name).
- Progress/settings are saved per user in `data/users/<user_id>/progress.json`.
- The server can suggest a profile based on your IP for quick login (LAN use).
- For internet-facing use, put behind VPN/proxy with real authentication.
