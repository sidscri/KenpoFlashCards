# 🥋 Kenpo Flashcards Web Server — Windows Service + Tray

> This is a **sub-project** inside the `sidscri-apps` monorepo.  
> Folder: `KenpoFlashcardsWebServer_Service_Tray/`

Windows background service with system tray icon for KenpoFlashcardsWebServer.  
Runs like Sonarr/Radarr — starts on boot, lives in the tray.

**Current Version:** v1.0.0 v3 (build 3)  
**Based on:** KenpoFlashcardsWebServer v5.5.2 (build 29)  
**Changelog:** [CHANGELOG.md](CHANGELOG.md)

---

## ✨ Features

- ✅ Runs on boot as a **Windows Service** (via NSSM)
- ✅ **System tray icon** with context menu
- ✅ Start / Stop / Restart controls
- ✅ "Open in Browser" quick action
- ✅ Auto-start on Windows login (optional)
- ✅ Status indicator in tray
- ✅ GitHub Actions automated builds

### Server Features (v5.5.2)
- ✅ Encrypted API key storage for ChatGPT and Gemini
- ✅ AI Access page for managing API keys and model selection
- ✅ Admin diagnostics page with health/version/AI status
- ✅ User Guide page with PDF download
- ✅ About page with creator/contact info
- ✅ Stable card ID mapping for cross-device sync
- ✅ Case-insensitive login
- ✅ Admin users managed via `admin_users.json`

---

## 🚀 Quick Start (Developer Mode)

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open: `http://localhost:8009`

---

## 🔧 Install as Windows Service (Recommended)

### Prerequisites
1. Download [NSSM](https://nssm.cc/) (Non-Sucking Service Manager)
2. Place `nssm.exe` in: `windows_service\nssm.exe`

### Installation
1. Right-click `INSTALL_Service_NSSM.bat` → **Run as Administrator**
2. Set environment variables:
   ```bat
   windows_service\SET_Service_Env.bat
   ```
3. Service will auto-start on boot

### Service Management
```bat
# Start service
net start KenpoFlashcardsWeb

# Stop service
net stop KenpoFlashcardsWeb

# Check status
sc query KenpoFlashcardsWeb
```

---

## 🖥️ Tray Icon (Optional)

### Install Tray Dependencies
```bat
windows_tray\INSTALL_Tray_Dependencies.bat
```

### Start Tray
```bat
windows_tray\START_Tray.bat
```

### Tray Menu Options
- **Open Browser** - Opens `http://localhost:8009`
- **Start Server** - Starts the background service
- **Stop Server** - Stops the background service
- **Restart Server** - Restart the service
- **Exit** - Close tray icon (service keeps running)

---

## ⚙️ Configuration

### Environment Variables
| Variable | Description |
|----------|-------------|
| `KENPO_ROOT` | Root path for auto-discovering card data |
| `KENPO_JSON_PATH` | Direct path to `kenpo_words.json` |
| `OPENAI_API_KEY` | OpenAI API key for AI features |
| `KENPO_WEB_PORT` | Server port (default: 8009) |

### Data Path Auto-Mapping
The server supports automatic path discovery. Set `KENPO_ROOT` to your monorepo path:
```
KENPO_ROOT=C:\Users\Sidscri\Documents\GitHub\sidscri-apps
```

See `windows_service\README_windows_service_tray.md` for details.

---

## 📁 Project Structure

```
KenpoFlashcardsWebServer_Service_Tray/
├── app.py                    # Main Flask application
├── requirements.txt          # Python dependencies
├── CHANGELOG.md
├── README.md
├── version.json
├── windows_service/
│   ├── INSTALL_Service_NSSM.bat
│   ├── UNINSTALL_Service_NSSM.bat
│   ├── SET_Service_Env.bat
│   ├── RESTART_Service.bat
│   └── README_windows_service_tray.md
├── windows_tray/
│   ├── kenpo_tray.py
│   ├── icon.png
│   ├── requirements_tray.txt
│   ├── INSTALL_Tray_Dependencies.bat
│   └── START_Tray.bat
├── static/
│   ├── index.html
│   ├── app.js
│   ├── styles.css
│   ├── about.html
│   ├── admin.html
│   ├── ai-access.html
│   ├── user-guide.html
│   └── favicon.ico
└── data/
    ├── profiles.json
    ├── breakdowns.json
    ├── helper.json
    ├── admin_users.json
    └── users/
```

---

## 🔨 Automated Builds

GitHub Actions automatically builds the tray EXE on push to `main`.

**Workflow:** `.github/workflows/build-windows-service-tray.yml`

**Artifacts produced:**
- `KenpoFlashcardsTray` - Standalone tray application EXE

---

## 📋 Version History

| Version | Build | Key Changes |
|---------|-------|-------------|
| **v1.0.0** | 3 | Updated to KenpoFlashcardsWebServer v5.5.2 (build 29), graduated from beta |
| **beta** | 2 | GitHub Actions workflow fixes, artifact upload path fix |
| **beta** | 1 | Initial release, system tray + service integration |

---

## ⚠️ Known Limitations

- Windows only (uses `pystray` for tray functionality)
- Server logs viewable only via log file (not in tray UI)
- Requires administrator privileges for service installation
- Auto-start requires running installer as admin

---

## 🔗 Related Projects

- **Core Server:** `../KenpoFlashcardsWebServer/`
- **Packaged Installer:** `../KenpoFlashcardsWebServer_Packaged/`
- **Android App:** `../KenpoFlashcardsProject-v2/`

---

## 📄 License

MIT — see `LICENSE`
