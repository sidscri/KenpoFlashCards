# Windows background mode

See `windows_service/README_windows_service_tray.md`.
