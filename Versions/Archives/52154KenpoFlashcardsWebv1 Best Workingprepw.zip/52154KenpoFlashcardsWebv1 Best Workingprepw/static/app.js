let allGroups = [];
let scopeGroup = "";         // selected group for studying ("" means all)
let allCardsMode = true; // studying all cards across groups    // “All Cards” button (flat mode)
let activeTab = "active";    // active | unsure | learned
let deck = [];
let deckIndex = 0;

let settingsAll = null;      // global settings
let settingsGroup = {};      // group overrides (loaded on demand)

const $ = (id) => document.getElementById(id);
function bind(id, evt, fn){
  const el = $(id);
  if(!el){ console.warn("Missing element:", id); return; }
  el.addEventListener(evt, fn);
}

let currentUser = null; // {id, first, last}
let appInitialized = false;

async function postLoginInit(){
  if(appInitialized) return;
  await loadGroups();
  await loadHealth();
  await refreshCounts();
  // default start view
  setTab("active");
  appInitialized = true;
}


function showAuthOverlay(){ $("authOverlay").classList.remove("hidden"); }
function hideAuthOverlay(){ $("authOverlay").classList.add("hidden"); }

function setAuthView(view){
  $("candidateBox").classList.toggle("hidden", view !== "candidate");
  $("registerBox").classList.toggle("hidden", view !== "register");
}

function setUserLine(){
  if(currentUser){
    $("userLine").textContent = `User: ${currentUser.first} ${currentUser.last}`;
  } else {
    $("userLine").textContent = "";
  }
}

async function ensureLoggedIn(){
  const me = await fetch("/api/me").then(r=>r.json());
  if(me.logged_in){
    currentUser = me.user;
    setUserLine();
    hideAuthOverlay();
    if(!appInitialized){
      try{ await postLoginInit(); } catch(e){}
    }
    return true;
  }

  currentUser = null;
  setUserLine();
  showAuthOverlay();

  if(me.candidate){
    $("authMessage").textContent = "";
    $("candidateName").textContent = `${me.candidate.first} ${me.candidate.last}`;
    setAuthView("candidate");
  } else {
    $("authMessage").textContent = "Please create your profile to start.";
    setAuthView("register");
  }
  return false;
}


async function jget(url){
  const r = await fetch(url);
  if(r.status === 401){
    await ensureLoggedIn();
    throw new Error("login_required");
  }
  if(!r.ok) throw new Error(await r.text());
  return r.json();
}
async function jpost(url, body){
  const r = await fetch(url, {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body||{})});
  if(r.status === 401){
    await ensureLoggedIn();
    throw new Error("login_required");
  }
  if(!r.ok) throw new Error(await r.text());
  return r.json();
}

function setStatus(msg){ $("status").textContent = msg; }

function escapeHtml(str){
  return String(str ?? "")
    .replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;")
    .replaceAll('"',"&quot;").replaceAll("'","&#039;");
}

function shuffle(a){
  for(let i=a.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    [a[i],a[j]]=[a[j],a[i]];
  }
}

function isFlipped(){ return $("card").classList.contains("flipped"); }
function flip(){ $("card").classList.toggle("flipped"); }

function setTab(tab){
  activeTab = tab;

  
  // Update action button label based on current study tab
  const ub = $("unsureBtn");
  if(ub) ub.textContent = (tab === "unsure") ? "Relearn" : "Unsure";
for(const [id, name] of [["tabActive","active"],["tabUnsure","unsure"],["tabLearned","learned"]]){
    $(id).classList.toggle("active", tab===name);
  }

  const study = (tab === "active" || tab === "unsure");
  $("viewStudy").classList.toggle("hidden", !study);
  $("viewList").classList.toggle("hidden", study);
  $("viewSettings").classList.add("hidden");

  refresh();
}

async function refreshCounts(){
  try{
    const groupParam = scopeGroup ? `&group=${encodeURIComponent(scopeGroup)}` : "";
    const c = await jget(`/api/counts?${groupParam}`);
    $("countsLine").textContent = `Active: ${c.active} | Unsure: ${c.unsure} | Learned: ${c.learned}`;
  } catch(e){
    $("countsLine").textContent = `Active: — | Unsure: — | Learned: —`;
  }
}

async function loadHealth(){
  const h = await jget("/api/health");
  // Don't show local file path on the page
  $("healthLine").textContent = `Cards loaded: ${h.cards_loaded}`;
}

async function loadGroups(){
  allGroups = await jget("/api/groups");

  const sel = $("groupSelect");
  sel.innerHTML = "";
  const optPick = document.createElement("option");
  optPick.value = "";
  optPick.textContent = "Select group…";
  sel.appendChild(optPick);

  for(const g of allGroups){
    const o = document.createElement("option");
    o.value = g;
    o.textContent = g;
    sel.appendChild(o);
  }

  scopeGroup = "";
  sel.value = "";
  allCardsMode = true;

  sel.addEventListener("change", () => {
    scopeGroup = sel.value;
    allCardsMode = scopeGroup ? false : true;
    refresh();
  });

  const scopeSel = $("settingsScope");
  scopeSel.innerHTML = "";
  const sAll = document.createElement("option");
  sAll.value = "all";
  sAll.textContent = "All Groups";
  scopeSel.appendChild(sAll);

  for(const g of allGroups){
    const o = document.createElement("option");
    o.value = g;
    o.textContent = g;
    scopeSel.appendChild(o);
  }
}

async function getScopeSettings(){
  if(!settingsAll){
    const res = await jget("/api/settings?scope=all");
    settingsAll = res.settings;
  }

  if(!scopeGroup){
    return settingsAll;
  }

  if(!(scopeGroup in settingsGroup)){
    const res = await jget(`/api/settings?scope=${encodeURIComponent(scopeGroup)}`);
    settingsGroup[scopeGroup] = res.settings || {};
  }

  return { ...settingsAll, ...settingsGroup[scopeGroup] };
}

function labelFor(card, settings){
  const showGroup = settings.show_group_label !== false;
  const showSub  = settings.show_subgroup_label !== false;

  const g = (card.group || "").trim();
  const sg = (card.subgroup || "").trim();

  const parts = [];
  if(showGroup && g) parts.push(g);
  if(showSub && sg) parts.push(sg);

  return parts.join(" • ");
}

function buildDeck(cards, settings){
  // All Cards (across groups)
  if(allCardsMode){
    if(settings.all_mode === "flat"){
      const d = cards.slice();
      if(settings.randomize) shuffle(d);
      else if(settings.card_order === "alpha"){
        d.sort((a,b)=> (a.term||"").localeCompare(b.term||""));
      }
      return d;
    }

    // grouped
    const byGroup = new Map();
    for(const c of cards){
      const g = c.group || "General";
      if(!byGroup.has(g)) byGroup.set(g, []);
      byGroup.get(g).push(c);
    }

    let groupList = Array.from(byGroup.keys());
    if(settings.group_order === "alpha"){
      groupList.sort((a,b)=> a.localeCompare(b));
    }

    const out = [];
    for(const g of groupList){
      const arr = byGroup.get(g);
      if(settings.randomize){
        shuffle(arr);
      } else if(settings.card_order === "alpha"){
        arr.sort((a,b)=> (a.term||"").localeCompare(b.term||""));
      }
      out.push(...arr);
    }
    return out;
  }

  // Studying a specific group
  const d = cards.slice();
  if(settings.randomize) shuffle(d);
  else if(settings.card_order === "alpha"){
    d.sort((a,b)=> (a.term||"").localeCompare(b.term||""));
  }
  return d;
}

function renderStudyCard(){
  $("card").classList.remove("flipped");

  if(!deck.length){
    $("pillLabel").textContent = scopeGroup ? scopeGroup : "All Cards";
    $("frontText").textContent = "No cards left 🎉";
    $("frontSub").textContent = "";
    $("backText").textContent = "Everything here has been moved out of this list.";
    $("backSub").textContent = "";
    $("cardPos").textContent = "Card 0 / 0";
    return;
  }

  const c = deck[deckIndex];
  const settings = window.__activeSettings || settingsAll || {};

  const label = labelFor(c, settings);
  $("pillLabel").textContent = label;
  $("pillLabel").style.visibility = label ? "visible" : "hidden";

  const reversed = !!settings.reverse_faces;

  const frontMain = reversed ? c.meaning : c.term;
  const backMain  = reversed ? c.term : c.meaning;

  const pron = (c.pron || "").trim();

  // keep pron optional; hide if empty
  $("frontSub").textContent = (!reversed && pron) ? `Pron: ${pron}` : "";
  $("backSub").textContent  = (reversed && pron) ? `Pron: ${pron}` : "";

  $("frontText").textContent = frontMain || "";
  $("backText").textContent = backMain || "";

  $("cardPos").textContent = `Card ${deckIndex+1} / ${deck.length}`;
}

function speakCurrent(){
  if(!deck.length) return;
  const c = deck[deckIndex];
  const settings = window.__activeSettings || settingsAll || {};
  const reversed = !!settings.reverse_faces;

  const say = isFlipped()
    ? (reversed ? c.term : c.meaning)
    : (reversed ? c.meaning : c.term);

  if(!say) return;

  if(!("speechSynthesis" in window)){
    setStatus("Speech not supported in this browser.");
    return;
  }

  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(say);
  u.rate = 0.95;
  window.speechSynthesis.speak(u);
}

async function loadDeckForStudy(){
  const settings = await getScopeSettings();
  window.__activeSettings = settings;

  const q = ($("searchBox").value || "").trim();
  const groupParam = scopeGroup ? `&group=${encodeURIComponent(scopeGroup)}` : "";
  const statusParam = `status=${encodeURIComponent(activeTab)}`;
  const qParam = q ? `&q=${encodeURIComponent(q)}` : "";

  const cards = await jget(`/api/cards?${statusParam}${groupParam}${qParam}`);
  deck = buildDeck(cards, settings);
  deckIndex = 0;

  renderStudyCard();
}

async function setCurrentStatus(status){
  if(!deck.length) return;
  const c = deck[deckIndex];
  await jpost("/api/set_status", {id: c.id, status});

  deck.splice(deckIndex, 1);
  if(deckIndex >= deck.length) deckIndex = 0;

  await refreshCounts();
  renderStudyCard();
}

function nextCard(){
  if(!deck.length) return;
  deckIndex = (deckIndex + 1) % deck.length;
  renderStudyCard();
}
function prevCard(){
  if(!deck.length) return;
  deckIndex = (deckIndex - 1 + deck.length) % deck.length;
  renderStudyCard();
}

async function loadList(status){
  const q = ($("searchBox").value || "").trim();
  const groupParam = scopeGroup ? `&group=${encodeURIComponent(scopeGroup)}` : "";
  const qParam = q ? `&q=${encodeURIComponent(q)}` : "";
  const cards = await jget(`/api/cards?status=${encodeURIComponent(status)}${groupParam}${qParam}`);

  const titleMap = {learned:"Learned", deleted:"Deleted"};
  $("listTitle").textContent = titleMap[status] || "List";

  const bulk = $("bulkBtns");
  bulk.innerHTML = "";

  const mkBtn = (txt, cls, onClick) => {
    const b = document.createElement("button");
    b.textContent = txt;
    b.className = cls;
    b.addEventListener("click", onClick);
    return b;
  };

  const selectedIds = () => Array.from(document.querySelectorAll("input[data-id]:checked")).map(x => x.getAttribute("data-id"));

  if(status === "learned"){
    bulk.appendChild(mkBtn("Move to Active", "secondary", async ()=>{
      const ids = selectedIds(); if(!ids.length) return;
      await jpost("/api/bulk_set_status", {ids, status:"active"});
      await refresh();
    }));
    bulk.appendChild(mkBtn("Move to Unsure", "secondary", async ()=>{
      const ids = selectedIds(); if(!ids.length) return;
      await jpost("/api/bulk_set_status", {ids, status:"unsure"});
      await refresh();
    }));
  }

  if(status === "deleted"){
    bulk.appendChild(mkBtn("Restore to Active", "secondary", async ()=>{
      const ids = selectedIds(); if(!ids.length) return;
      await jpost("/api/bulk_set_status", {ids, status:"active"});
      await refresh();
    }));
    bulk.appendChild(mkBtn("Restore to Unsure", "secondary", async ()=>{
      const ids = selectedIds(); if(!ids.length) return;
      await jpost("/api/bulk_set_status", {ids, status:"unsure"});
      await refresh();
    }));
  }

  const list = $("list");
  list.innerHTML = "";

  if(!cards.length){
    list.textContent = "No cards found in this list.";
    return;
  }

  for(const c of cards){
    const row = document.createElement("div");
    row.className = "item";

    const left = document.createElement("div");
    left.className = "itemLeft";

    const chk = document.createElement("input");
    chk.type = "checkbox";
    chk.className = "chk";
    chk.setAttribute("data-id", c.id);

    const text = document.createElement("div");
    const lbl = (c.group || "").trim();
    text.innerHTML = `<b>${escapeHtml(c.term)}</b>
      <small>${escapeHtml(c.meaning)}${c.pron ? `<br/>Pron: ${escapeHtml(c.pron)}` : ""}${lbl ? `<br/>${escapeHtml(lbl)}` : ""}</small>`;

    left.appendChild(chk);
    left.appendChild(text);

    const right = document.createElement("div");
    right.className = "itemRight";

    if(status === "learned"){
      const b1 = document.createElement("button");
      b1.className = "secondary"; b1.textContent = "→ Active";
      b1.addEventListener("click", async ()=>{ await jpost("/api/set_status", {id:c.id, status:"active"}); await refresh(); });

      const b2 = document.createElement("button");
      b2.className = "secondary"; b2.textContent = "→ Unsure";
      b2.addEventListener("click", async ()=>{ await jpost("/api/set_status", {id:c.id, status:"unsure"}); await refresh(); });

      right.appendChild(b1); right.appendChild(b2);
    }

    if(status === "deleted"){
      const b1 = document.createElement("button");
      b1.className = "secondary"; b1.textContent = "Restore";
      b1.addEventListener("click", async ()=>{ await jpost("/api/set_status", {id:c.id, status:"active"}); await refresh(); });
      right.appendChild(b1);
    }

    row.appendChild(left);
    row.appendChild(right);
    list.appendChild(row);
  }
}

async function refresh(){
  if(!currentUser){
    const ok = await ensureLoggedIn();
    if(!ok) return;
  }
  await refreshCounts();

  if(!$("viewSettings").classList.contains("hidden")){
    return;
  }

  if(activeTab === "active" || activeTab === "unsure"){
    await loadDeckForStudy();
    const s = window.__activeSettings || settingsAll || {};
    const allLabel = (s.all_mode === "flat") ? "All (flat)" : "All (grouped)";
    setStatus(`${(scopeGroup || (allCardsMode ? allLabel : ""))} • Studying: ${activeTab}`);
  } else {
    $("viewStudy").classList.add("hidden");
    $("viewList").classList.remove("hidden");
    await loadList(activeTab);
    setStatus(`${(scopeGroup||"All")} • Viewing: ${activeTab}`);
  }
}

async function openSettings(){
  if(!appInitialized){
    try{ await postLoginInit(); } catch(e){}
  }
  $("viewSettings").classList.remove("hidden");
  $("viewStudy").classList.add("hidden");
  $("viewList").classList.add("hidden");

  $("settingsScope").value = "all";
  await loadSettingsForm("all");
}

async function loadSettingsForm(scope){
  if(!scope) scope = "all";
  const res = await jget(`/api/settings?scope=${encodeURIComponent(scope)}`);
  const s = res.settings || {};

  let effective = s;
  if(scope !== "all"){
    if(!settingsAll){
      const g = await jget("/api/settings?scope=all");
      settingsAll = g.settings;
    }
    effective = { ...settingsAll, ...s };
  }

  $("setRandomize").checked = !!effective.randomize;
  $("setShowGroup").checked = effective.show_group_label !== false;
  $("setShowSubgroup").checked = effective.show_subgroup_label !== false;
  $("setReverseFaces").checked = !!effective.reverse_faces;

  $("setAllMode").value = effective.all_mode || "grouped";
  $("setGroupOrder").value = effective.group_order || "alpha";
  $("setCardOrder").value = effective.card_order || "json";
}

async function saveSettings(){
  let scope = $("settingsScope").value;
  if(!scope) scope = "all";

  const patch = {
    randomize: $("setRandomize").checked,
    show_group_label: $("setShowGroup").checked,
    show_subgroup_label: $("setShowSubgroup").checked,
    reverse_faces: $("setReverseFaces").checked,
    all_mode: $("setAllMode").value,
    group_order: $("setGroupOrder").value,
    card_order: $("setCardOrder").value
  };

  await jpost("/api/settings", {scope, settings: patch});

  settingsAll = null;
  settingsGroup = {};
  window.__activeSettings = null;

  await refreshCounts();
  await refresh();
}

async function main(){

  // Auth modal buttons
  bind("btnCandidateYes","click", async ()=>{
    try{
      const res = await jpost("/api/confirm_candidate", {confirm:true, remember_ip:true});
      currentUser = res.user;
      setUserLine();
      hideAuthOverlay();
      appInitialized = false;
      await postLoginInit();
      await refresh();
    } catch(e){}
  });

  bind("btnCandidateNo","click", async ()=>{
    try{ await jpost("/api/confirm_candidate", {confirm:false}); } catch(e){}
    $("authMessage").textContent = "Create your profile to start.";
    setAuthView("register");
  });

  bind("btnRegister","click", async ()=>{
    const first = ($("regFirst").value || "").trim();
    const last  = ($("regLast").value || "").trim();
    const remember = !!$("regRemember").checked;
    if(!first || !last){
      $("authMessage").textContent = "Please enter both first and last name.";
      return;
    }
    try{
      const res = await jpost("/api/register", {first, last, remember_ip: remember});
      currentUser = res.user;
      setUserLine();
      hideAuthOverlay();
      appInitialized = false;
      await postLoginInit();
      await refresh();
    } catch(e){
      $("authMessage").textContent = "Could not create profile. Try again.";
    }
  });

  bind("logoutBtn","click", async ()=>{
    try{ await jpost("/api/logout", {}); } catch(e){}
    currentUser = null;
    setUserLine();
    appInitialized = false;
    allGroups = [];
    try{ $("groupSelect").innerHTML = ""; } catch(e){}
    try{ $("settingsScope").innerHTML = ""; } catch(e){}
    await ensureLoggedIn();
  });
  bind("tabActive","click", ()=>setTab("active"));
  bind("tabUnsure","click", ()=>setTab("unsure"));
  bind("tabLearned","click", ()=>setTab("learned"));

  bind("nextBtn","click", nextCard);
  bind("prevBtn","click", prevCard);
  bind("speakBtn","click", speakCurrent);

  bind("gotItBtn","click", ()=>setCurrentStatus("learned"));
  bind("unsureBtn","click", ()=>{
    if(activeTab === "unsure") return setCurrentStatus("active");
    return setCurrentStatus("unsure");
  });
bind("card","click", flip);
  bind("card","keydown", (e)=>{
    if(e.code === "Space" || e.code === "Enter"){
      e.preventDefault(); flip();
    }
  });

  bind("searchBox","input", async ()=>{ await refresh(); });

  bind("allCardsBtn","click", async ()=>{
    scopeGroup = "";
    $("groupSelect").value = "";
    allCardsMode = true;
    await refresh();
  });

  bind("settingsBtn","click", openSettings);
  bind("closeSettingsBtn","click", async ()=>{
    $("viewSettings").classList.add("hidden");
    if(activeTab === "active" || activeTab === "unsure"){
      $("viewStudy").classList.remove("hidden");
    } else {
      $("viewList").classList.remove("hidden");
    }
    await refresh();
  });

  bind("settingsScope","change", async ()=>{
    await loadSettingsForm($("settingsScope").value);
  });

  bind("saveSettingsBtn","click", saveSettings);
  bind("resetSettingsBtn","click", async ()=>{
    let scope = $("settingsScope").value;
    if(!scope) scope = "all";
    if(!confirm("Reset settings to defaults for this scope?")) return;
    try{
      await jpost("/api/settings_reset", {scope});
      // clear cached settings + reload form
      settingsAll = null;
      settingsGroup = {};
      window.__activeSettings = null;
      await loadSettingsForm(scope);
      await refresh();
    } catch(e){
      console.error(e);
    }
  });

  const ok = await ensureLoggedIn();
  if(!ok) return;
  await postLoginInit();
}

main().catch(err=>{
  console.error(err);
  setStatus("Error: " + err.message);
});
